import httpx
SPOT="https://data-api.binance.vision"
FUTURES="https://fapi.binance.com"
async def _get(url,params=None):
 async with httpx.AsyncClient(timeout=12) as client:
  r=await client.get(url,params=params); r.raise_for_status(); return r.json()
async def get_market_summary(market):
 base=SPOT if market=="spot" else FUTURES
 path="/api/v3/ticker/24hr" if market=="spot" else "/fapi/v1/ticker/24hr"
 data=await _get(base+path)
 pairs=[{"symbol":x.get("symbol"),"lastPrice":float(x.get("lastPrice",0)),"priceChangePercent":float(x.get("priceChangePercent",0)),"quoteVolume":float(x.get("quoteVolume",0)),"highPrice":float(x.get("highPrice",0)),"lowPrice":float(x.get("lowPrice",0))} for x in data if str(x.get("symbol","")).endswith("USDT")]
 pairs.sort(key=lambda x:x["quoteVolume"],reverse=True)
 return {"market":market,"count":len(pairs),"top_by_quote_volume":pairs[:100]}
async def get_klines(market,symbol,interval,limit):
 base=SPOT if market=="spot" else FUTURES
 path="/api/v3/klines" if market=="spot" else "/fapi/v1/klines"
 raw=await _get(base+path,{"symbol":symbol,"interval":interval,"limit":limit})
 return [{"openTime":int(r[0]),"open":float(r[1]),"high":float(r[2]),"low":float(r[3]),"close":float(r[4]),"volume":float(r[5]),"closeTime":int(r[6]),"quoteVolume":float(r[7]),"trades":int(r[8])} for r in raw]
