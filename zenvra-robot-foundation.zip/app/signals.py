from statistics import mean
def analyze_candles(candles,market,symbol,interval):
 if len(candles)<30: return {"market":market,"symbol":symbol,"status":"insufficient_data","candidate":None}
 closed=candles[:-1]; last=closed[-1]; prior=closed[-23:-3]
 hi=max(c["high"] for c in prior); lo=min(c["low"] for c in prior)
 sweep_low=last["low"]<lo and last["close"]>lo
 sweep_high=last["high"]>hi and last["close"]<hi
 avg=mean(c["volume"] for c in closed[-21:-1]) or 1
 ratio=last["volume"]/avg
 direction="LONG" if sweep_low else ("SHORT" if sweep_high else None)
 accepted=direction is not None and ratio>=1.5
 return {"market":market,"symbol":symbol,"interval":interval,"status":"candidate" if accepted else "no_setup","candidate":{"direction":direction,"score":85,"last_close":last["close"],"prior_range_high":hi,"prior_range_low":lo,"volume_ratio":round(ratio,2),"reasons":["liquidity sweep and close back inside range","volume >= 1.5x recent average"],"note":"Experimental heuristic; not a validated win-rate model."} if accepted else None,"diagnostics":{"sweep_low":sweep_low,"sweep_high":sweep_high,"volume_ratio":round(ratio,2)},"auto_trading":False}
