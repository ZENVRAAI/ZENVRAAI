from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from .market import get_market_summary, get_klines
from .signals import analyze_candles
app=FastAPI(title="ZENVRA AI Robot Foundation",version="0.1.0",description="Read-only market data and experimental signal candidates.")
app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_credentials=False,allow_methods=["GET"],allow_headers=["*"])
@app.get("/")
def root(): return {"app":"ZENVRA AI","status":"running","mode":"read-only","auto_trading":False}
@app.get("/health")
def health(): return {"ok":True}
@app.get("/market/{market}")
async def market(market:str):
 if market.lower() not in ("spot","futures"): raise HTTPException(400,"market must be spot or futures")
 try: return await get_market_summary(market.lower())
 except Exception as e: raise HTTPException(502,"Market data provider error: "+type(e).__name__)
@app.get("/candles/{market}/{symbol}")
async def candles(market:str,symbol:str,interval:str=Query("15m",pattern="^(1m|3m|5m|15m|30m|1h|2h|4h|1d)$"),limit:int=Query(150,ge=30,le=500)):
 if market.lower() not in ("spot","futures"): raise HTTPException(400,"market must be spot or futures")
 try: return {"market":market.lower(),"symbol":symbol.upper(),"interval":interval,"candles":await get_klines(market.lower(),symbol.upper(),interval,limit)}
 except Exception as e: raise HTTPException(502,"Market data provider error: "+type(e).__name__)
@app.get("/analyze/{market}/{symbol}")
async def analyze(market:str,symbol:str,interval:str=Query("15m",pattern="^(1m|3m|5m|15m|30m|1h|2h|4h|1d)$")):
 if market.lower() not in ("spot","futures"): raise HTTPException(400,"market must be spot or futures")
 try: return analyze_candles(await get_klines(market.lower(),symbol.upper(),interval,150),market.lower(),symbol.upper(),interval)
 except Exception as e: raise HTTPException(502,"Analysis provider error: "+type(e).__name__)
