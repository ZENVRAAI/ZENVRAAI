from app.signals import analyze_candles
def test_no_setup():
 rows=[{"openTime":i,"open":100,"high":102,"low":98,"close":100,"volume":100,"closeTime":i+1,"quoteVolume":10000,"trades":10} for i in range(40)]
 result=analyze_candles(rows,"spot","BTCUSDT","15m")
 assert result["status"]=="no_setup" and result["auto_trading"] is False
def test_insufficient_data():
 assert analyze_candles([], "spot","BTCUSDT","15m")["status"]=="insufficient_data"
