# ZENVRA AI — Robot Foundation v0.1

Separate starter service to continue while GitHub write access is unresolved.

## Included
- Read-only public Binance Spot and USDⓈ-M Futures market data.
- Top 100 USDT pairs by 24-hour quote volume.
- Candle endpoints and an experimental liquidity-sweep plus volume heuristic.
- Health endpoint and interactive API docs at `/docs`.
- No trade execution, exchange keys, or promise of signal accuracy.

## Not production-ready yet
No database, scheduled 24/7 scanner, Telegram alerts, signal journal, or trained LSTM/XGBoost models yet. The heuristic is experimental and must be backtested and paper-traded before relying on it.

## Run
`pip install -r requirements.txt`
`uvicorn app.main:app --host 0.0.0.0 --port 8000`
Open `/docs`.

## API
- `GET /health`
- `GET /market/spot`
- `GET /market/futures`
- `GET /candles/spot/BTCUSDT?interval=15m&limit=150`
- `GET /analyze/futures/BTCUSDT?interval=15m`

Dockerfile and Render blueprint are included for deployment.
Official docs: https://github.com/binance/binance-spot-api-docs
https://developers.binance.com/en/docs/catalog
